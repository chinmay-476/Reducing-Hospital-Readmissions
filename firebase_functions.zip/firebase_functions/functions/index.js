const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

admin.initializeApp();

const PREDICTION_API_URL = 'http://127.0.0.1:5000'; // Replace with your deployed API URL

exports.predictReadmissionRisk = functions.firestore
  .document('patients/{patientId}')
  .onCreate(async (snap, context) => {
    const patientData = snap.data();

    // Prepare payload for the prediction API
    const payload = {
      age: patientData.age,
      num_prior_admissions: patientData.num_prior_admissions,
      comorbidity_score: patientData.comorbidity_score,
      emergency_admission: patientData.emergency_admission,
      nutritional_status: patientData.nutritional_status,
    };

    try {
      const response = await axios.post(PREDICTION_API_URL, payload);
      const riskScore = response.data.readmission_risk_score;

      if (riskScore !== undefined) {
        await snap.ref.update({
          readmission_risk_score: riskScore,
          risk_level:
            riskScore > 0.7
              ? 'High'
              : riskScore > 0.4
              ? 'Medium'
              : 'Low',
          risk_calculated_at: admin.firestore.FieldValue.serverTimestamp(),
        });
      } else {
        console.error('Prediction API returned no risk score:', response.data);
      }
    } catch (error) {
      console.error('Error calling prediction API:', error.message);
    }
  });
