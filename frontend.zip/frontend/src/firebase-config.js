// Replace these config values with your Firebase project config from console
const firebaseConfig = {
  apiKey: "AIzaSyCrjZS6Zkyl4ntmwP5SlOkD5W2tMFbMgds",
  authDomain: "steel-ridge-401809.firebaseapp.com",
  databaseURL: "https://steel-ridge-401809-default-rtdb.firebaseio.com",
  projectId: "steel-ridge-401809",
  storageBucket: "steel-ridge-401809.appspot.com",
  messagingSenderId: "1059959663110",
  appId: "1:1059959663110:web:81d06e049fa558a5f9f187",
  measurementId: "G-94PDRSGXG9"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
