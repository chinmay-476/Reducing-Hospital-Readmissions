async function displayPatientRisk() {
  const patientId = document.getElementById("patientId").value.trim();
  if (!patientId) {
    alert("Please enter a patient document ID.");
    return;
  }

  try {
    const docRef = db.collection("patients").doc(patientId);
    const doc = await docRef.get();
    const riskScoreEl = document.getElementById("riskScore");

    if (!doc.exists) {
      riskScoreEl.textContent = "Patient not found.";
      riskScoreEl.className = '';
      return;
    }

    const data = doc.data();
    if (data.readmission_risk_score === undefined) {
      riskScoreEl.textContent = "Risk score not yet calculated.";
      riskScoreEl.className = '';
      return;
    }

    let riskClass = '';
    if (data.risk_level === 'High') riskClass = 'risk-high';
    else if (data.risk_level === 'Medium') riskClass = 'risk-medium';
    else if (data.risk_level === 'Low') riskClass = 'risk-low';

    riskScoreEl.textContent = `Readmission Risk Score: ${data.readmission_risk_score} (${data.risk_level})`;
    riskScoreEl.className = riskClass;
  } catch (error) {
    console.error("Error fetching patient data:", error);
    alert("An error occurred while fetching risk score.");
  }
}
