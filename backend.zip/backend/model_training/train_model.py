import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, roc_auc_score
import joblib

def main():
    # Step 1: Load dataset
    data = pd.read_csv('patient_data.csv')
    print("Columns in dataset:", data.columns.tolist())

    # Step 2: Verify target column
    if 'Readmitted' not in data.columns:
        raise ValueError("Dataset must have a 'Readmitted' column (0/1 labels)")

    # Step 3: Define columns to use
    feature_cols = [
        'Age', 'Gender', 'Blood Type', 'Medical Condition', 'Admission Type',
        'Billing Amount', 'Room Number', 'Discharge Date', 'Medication', 'Test Results'
    ]

    # Filter dataset and drop missing values from features + target
    dataset = data[feature_cols + ['Readmitted']].copy()
    initial_len = len(dataset)
    dataset.dropna(inplace=True)
    print(f"Dropped {initial_len - len(dataset)} rows due to missing values")

    # Step 4: Feature engineering for 'Discharge Date'
    if 'Date of Admission' in data.columns:
        # Convert dates to datetime
        dataset['Date of Admission'] = pd.to_datetime(data.loc[dataset.index, 'Date of Admission'], errors='coerce')
        dataset['Discharge Date'] = pd.to_datetime(dataset['Discharge Date'], errors='coerce')

        # Calculate length of stay
        dataset['Length_of_Stay'] = (dataset['Discharge Date'] - dataset['Date of Admission']).dt.days

        # Remove rows with invalid length_of_stay
        dataset = dataset[dataset['Length_of_Stay'].notnull() & (dataset['Length_of_Stay'] >= 0)]

        # Drop original date columns after feature creation
        dataset.drop(['Discharge Date', 'Date of Admission'], axis=1, inplace=True)
    else:
        # If no Date of Admission, drop Discharge Date as unusable
        dataset.drop(['Discharge Date'], axis=1, inplace=True)
        print("Warning: 'Date of Admission' not found, dropped 'Discharge Date' column.")

    # Step 5: Separate features and target
    target_col = 'Readmitted'
    X = dataset.drop(columns=[target_col])
    y = dataset[target_col].astype(int)  # Ensure integer 0/1 labels
    print(f"Using features: {list(X.columns)}")
    print(f"Target distribution:\n{y.value_counts(normalize=True)}")

    # Step 6: Define categorical and numerical columns
    categorical_cols = ['Gender', 'Blood Type', 'Medical Condition', 'Admission Type', 'Medication', 'Test Results']
    # Length_of_Stay might exist after step 4
    numerical_cols = [col for col in X.columns if col not in categorical_cols]

    print(f"Categorical columns: {categorical_cols}")
    print(f"Numerical columns: {numerical_cols}")

    # Step 7: Build preprocessing pipeline
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols),
            ('num', 'passthrough', numerical_cols)
        ]
    )

    # Step 8: Build full pipeline with classifier
    model_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

    # Step 9: Split data into train/test sets with stratification
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Train samples: {X_train.shape[0]}, Test samples: {X_test.shape[0]}")

    # Step 10: Train the model
    model_pipeline.fit(X_train, y_train)

    # Step 11: Predict and evaluate
    y_pred = model_pipeline.predict(X_test)

    proba = model_pipeline.predict_proba(X_test)
    proba = np.array(proba)
    print(f"Raw predict_proba output shape: {proba.shape}")

    # Fix multi-dimensional output, if any
    if proba.ndim == 3:
        print("Detected 3D predict_proba output, adjusting by selecting first dimension.")
        proba = proba[0]
        print(f"Adjusted predict_proba shape: {proba.shape}")

    y_proba = proba[:, 1]  # Probability of positive class

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, zero_division=0))

    print(f"ROC AUC Score: {roc_auc_score(y_test, y_proba):.4f}")

    # Step 12: Save the trained pipeline
    joblib.dump(model_pipeline, 'readmission_model_pipeline.pkl')
    print("Model pipeline saved as 'readmission_model_pipeline.pkl'")

if __name__ == "__main__":
    main()
