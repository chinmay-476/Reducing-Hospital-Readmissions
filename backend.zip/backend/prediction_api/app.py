from flask import Flask, request, jsonify
import joblib
import pandas as pd
from datetime import datetime
import os

app = Flask(__name__)

# Load the trained model pipeline
model_path = os.path.join(os.path.dirname(__file__), 'readmission_model_pipeline.pkl')
model = joblib.load(model_path)

# Known features used in the model training
KNOWN_FEATURES = [
    'Age', 'Gender', 'Blood Type', 'Medical Condition', 'Admission Type',
    'Billing Amount', 'Room Number', 'Length_of_Stay', 'Medication', 'Test Results'
]

def calculate_length_of_stay(date_admission_str, discharge_date_str):
    try:
        date_adm = datetime.strptime(date_admission_str, '%Y-%m-%d')
        date_dis = datetime.strptime(discharge_date_str, '%Y-%m-%d')
        delta = date_dis - date_adm
        if delta.days < 0:
            return None
        return delta.days
    except Exception:
        return None

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)

    # Automatically compute Length_of_Stay if not provided, given date strings
    if 'Length_of_Stay' not in data:
        if 'Date of Admission' in data and 'Discharge Date' in data:
            los = calculate_length_of_stay(data['Date of Admission'], data['Discharge Date'])
            if los is None:
                return jsonify({'error': 'Invalid Date range for Length_of_Stay calculation'}), 400
            data['Length_of_Stay'] = los
        else:
            return jsonify({'error': 'Length_of_Stay or both Date of Admission and Discharge Date are required.'}), 400

    # Separate known and unknown columns
    input_features = {}
    new_columns = {}

    # Collect known features (with error if missing)
    missing_features = []
    for f in KNOWN_FEATURES:
        if f not in data:
            missing_features.append(f)
        else:
            input_features[f] = data[f]

    if missing_features:
        return jsonify({'error': f'Missing required features: {missing_features}'}), 400

    # Collect any new/extra columns from input
    for k, v in data.items():
        if k not in KNOWN_FEATURES:
            new_columns[k] = v

    # Create DataFrame for known features for prediction
    df_features = pd.DataFrame([input_features])

    # Add new columns to the DataFrame as additional columns (optional, for logging/tracking)
    for col, val in new_columns.items():
        df_features[col] = val  # vectorized assign; broadcasts since we have single row

    try:
        # Predict with only known features (so that pipeline works correctly)
        proba = model.predict_proba(df_features[KNOWN_FEATURES])[0][1]
    except Exception as e:
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500

    # Optional: return new columns back in response for confirmation
    return jsonify({
        'readmission_risk_score': round(proba, 4),
        'additional_columns_received': list(new_columns.keys())
    })

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=False)
